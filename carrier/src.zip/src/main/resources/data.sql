INSERT INTO carrier VALUES
  (1,'Good Carrier', 'abc@gmail.com', '1234567898'),
  (2,'Best Carrier',  'xyz@email.com', '4321567898'),
  (3,'CEI Carrier', 'cap@marvel.com', '9876543217');