INSERT INTO load VALUES
  (1,'2 Days', 'New york', 'Memphis', '2020-04-01', '2020-04-02',1,3),
  (2,'4 Days', 'Washingtom', 'Houston', '2020-04-03', '2020-04-04',2,2),
  (3,'6 Days', 'California', 'Pitsburg', '2020-04-05', '2020-04-06',1,2);

INSERT INTO commodity VALUES
  (1,'Apples',200,300,1),
  (2,'Oranges',400,500,2),
  (3,'Grapes',600,400,1);


