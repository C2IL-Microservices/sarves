INSERT INTO customer VALUES
  (1,'Sarves', 'Waran', 'abc@gmail.com', '1234567898'),
  (2,'Deja', 'Vu', 'xyz@email.com', '4321567898'),
  (3,'Caption', 'America', 'cap@marvel.com', '9876543217');